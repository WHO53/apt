#!/bin/bash

dhcpd -f -4 -q -cf /etc/hybris-usb/dhcpd.conf -pf 
/run/hybris-usb/dhcpd4.pid -lf /run/hybris-usb/dhcpd4.lease
